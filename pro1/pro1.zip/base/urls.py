from django.urls import path
from .views import *
# APP
urlpatterns = [
    path('home/',home),
    path('about/',about)
]
